# SỬ DỤNG ANSIBLE CẤU HÌNH TỰ ĐỘNG VXLAN
![](assets/README-ac7aac69.png)

Tác giả:
- Trần Quốc Thái
- Đặng Ngọc Khoa
