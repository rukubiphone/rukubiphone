# Lab: Quản lý và triển khai tự động hạ tầng mạng dùng Ansible
![](assets/README-a98569a9.png)

### Yêu cầu máy workstation(Linux) đã cài đặt Ansible
